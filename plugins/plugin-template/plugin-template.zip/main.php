<?php

chdir(__DIR__);

require_once 'src/Logger.php';

(function () {
    $logger = new \SampleLogger\Logger();
    // if PLUGIN_DIRECTORY is provided, use it; else fall back to a directory one level up
    $pluginDir = getenv('PLUGIN_DIRECTORY') ?: dirname(__DIR__);
    $logger->log("Plugin's directory: $pluginDir");
    $logger->log('Finished');
})();
