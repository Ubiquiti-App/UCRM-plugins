<?php
require 'Database.php';
Database::install();
