# Ubiquiti UCRM - ToDo list
Simple non-shared ToDo list accessible from menu for UCRM admins. 

Just install zip and use, no settings is required.
