<script src="https://code.jquery.com/jquery-3.3.1.min.js"integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="crossorigin="anonymous"></script>
<script type="text/javascript" src="<?php echo $public_folder_path; ?>/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo $public_folder_path; ?>/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $public_folder_path; ?>/styles.css">