<?php

declare(strict_types=1);

namespace SmsNotifier\Exception;

class CurlException extends \Exception
{

}
