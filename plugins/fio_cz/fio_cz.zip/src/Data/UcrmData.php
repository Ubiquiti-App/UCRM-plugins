<?php

declare(strict_types=1);

namespace FioCz\Data;

class UcrmData
{
    /**
     * @var string
     */
    public $pluginAppKey;

    /**
     * @var string
     */
    public $ucrmPublicUrl;
}
