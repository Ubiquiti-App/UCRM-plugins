<?php

declare(strict_types=1);

namespace MikrotikQueueSync\Exception;

class CurlException extends \Exception
{

}
