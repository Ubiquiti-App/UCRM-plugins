<?php

declare(strict_types=1);

namespace ViberNotifier\Exception;

class CurlException extends \Exception
{

}
